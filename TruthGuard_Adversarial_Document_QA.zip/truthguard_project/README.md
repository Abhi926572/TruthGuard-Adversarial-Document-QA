# TruthGuard — Adversarial Verification for Multi-Agent Document Q&A

Implements the supplied problem statement with:
- Retriever agent
- Synthesizer agent
- Critic/adversary agent
- Conflict and staleness detection
- Unsupported-claim detection
- Transparent resolution with provenance

## Run
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
streamlit run app.py

Demo questions:
- Can an employee work remotely on Friday?
- How many days of parental leave are available?
- What is the expense approval limit?

The demo corpus intentionally contains conflicting and superseded documents.
