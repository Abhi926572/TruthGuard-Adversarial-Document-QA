import json
import re
from datetime import date
from dateutil import parser as date_parser
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class RetrieverAgent:
    def __init__(self, documents):
        self.documents = documents
        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        corpus = [d["title"] + " " + d["text"] for d in documents]
        self.matrix = self.vectorizer.fit_transform(corpus)

    def retrieve(self, question, k=6):
        q = self.vectorizer.transform([question])
        scores = cosine_similarity(q, self.matrix).ravel()
        ranked = scores.argsort()[::-1][:k]
        results = []
        for idx in ranked:
            if scores[idx] <= 0:
                continue
            item = dict(self.documents[idx])
            item["score"] = float(scores[idx])
            results.append(item)
        return results


class SynthesizerAgent:
    def synthesize(self, question, passages):
        if not passages:
            return {"answer": "I cannot answer this from the available documents.",
                    "claims": [], "source_ids": []}

        terms = set(re.findall(r"[a-zA-Z]{4,}", question.lower()))
        candidates = []

        for p in passages:
            for sentence in re.split(r"(?<=[.!?])\s+", p["text"]):
                words = set(re.findall(r"[a-zA-Z]{4,}", sentence.lower()))
                overlap = len(terms.intersection(words))
                if overlap:
                    candidates.append((overlap, p["score"], sentence.strip(), p["id"]))

        candidates.sort(reverse=True)
        chosen = candidates[:3]
        claims = [x[2] for x in chosen]
        source_ids = [x[3] for x in chosen]

        if not claims:
            return {
                "answer": "The retrieved documents do not contain enough evidence to answer this question.",
                "claims": [], "source_ids": []
            }

        return {
            "answer": " ".join(claims),
            "claims": claims,
            "source_ids": source_ids
        }


class CriticAgent:
    def _date(self, value):
        try:
            return date_parser.parse(value).date()
        except Exception:
            return date.min

    def check_conflicts(self, passages):
        conflicts = []
        by_topic = {}

        for p in passages:
            by_topic.setdefault(p["topic"], []).append(p)

        for topic, docs in by_topic.items():
            docs = sorted(docs, key=lambda x: self._date(x["date"]), reverse=True)

            active_docs = [d for d in docs if d.get("status") == "active"]
            for newer in active_docs:
                for older in docs:
                    if self._date(older["date"]) < self._date(newer["date"]) and older["status"] != "active":
                        conflicts.append({
                            "type": "staleness",
                            "explanation": (
                                f"{older['title']} ({older['date']}) is superseded by "
                                f"{newer['title']} ({newer['date']})."
                            )
                        })

            values = {}
            for p in docs:
                for key, value in p.get("claims", {}).items():
                    values.setdefault(key, []).append((str(value), p))

            for key, entries in values.items():
                unique = {}
                for value, p in entries:
                    unique.setdefault(value, []).append(p)

                if len(unique) > 1:
                    labels = [
                        f"{value} ({docs_for_value[0]['title']})"
                        for value, docs_for_value in unique.items()
                    ]
                    conflicts.append({
                        "type": "contradiction",
                        "explanation": f"Conflicting values for '{key}': " + "; ".join(labels)
                    })

        return conflicts

    def unsupported_claims(self, synthesis, passages):
        evidence = " ".join(p["text"].lower() for p in passages)
        unsupported = []

        for claim in synthesis["claims"]:
            words = [
                w for w in re.findall(r"[a-zA-Z]{5,}", claim.lower())
                if w not in {"which", "there", "their", "these", "those"}
            ]
            if words and sum(w in evidence for w in words) / len(words) < 0.55:
                unsupported.append(claim)

        return unsupported


class ResolutionAgent:
    def resolve(self, retrieved, synthesis, conflicts, unsupported):
        if not retrieved:
            return {
                "status": "unresolved",
                "answer": "I cannot resolve this question because no relevant evidence was retrieved.",
                "reasoning": "No supporting passage was found."
            }

        if any(c["type"] == "contradiction" for c in conflicts):
            return {
                "status": "conflict",
                "answer": (
                    "I found conflicting source claims, so I will not present a single "
                    "confident answer. See the conflict report and provenance below."
                ),
                "reasoning": (
                    "The critic detected incompatible values across retrieved documents. "
                    "TruthGuard surfaces the disagreement instead of blending the sources."
                )
            }

        if unsupported:
            return {
                "status": "conflict",
                "answer": "The evidence is insufficient to safely support every claim in the draft.",
                "reasoning": "The critic found one or more claims that were not adequately grounded."
            }

        return {
            "status": "resolved",
            "answer": synthesis["answer"],
            "reasoning": (
                "The answer is grounded in retrieved passages, and the critic found "
                "no direct contradiction or unsupported claim."
            )
        }


class TruthGuardSystem:
    def __init__(self, path):
        with open(path, "r", encoding="utf-8") as f:
            self.documents = json.load(f)

        self.retriever = RetrieverAgent(self.documents)
        self.synthesizer = SynthesizerAgent()
        self.critic = CriticAgent()
        self.resolver = ResolutionAgent()

    def answer(self, question):
        retrieved = self.retriever.retrieve(question)
        synthesis = self.synthesizer.synthesize(question, retrieved)
        conflicts = self.critic.check_conflicts(retrieved)
        unsupported = self.critic.unsupported_claims(synthesis, retrieved)

        resolution = self.resolver.resolve(
            retrieved, synthesis, conflicts, unsupported
        )

        return {
            **resolution,
            "retrieved": retrieved,
            "conflicts": conflicts,
            "unsupported_claims": unsupported,
            "draft": synthesis["answer"]
        }
